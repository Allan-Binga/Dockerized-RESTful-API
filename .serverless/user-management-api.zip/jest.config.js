export default {
    transform: {
      "^.+\\.[t|j]sx?$": "babel-jest",
    },
  };
  